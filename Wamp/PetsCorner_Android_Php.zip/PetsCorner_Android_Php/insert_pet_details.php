<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...


$pCategory = $_POST['pCategory'];
$pName = $_POST['pName'];
$pAge = $_POST['pAge'];
$pGender = $_POST['pGender'];
$pBreed = $_POST['pBreed'];
$pABout = $_POST['pABout'];
$pPrice = $_POST['pPrice'];
$pPriceType = $_POST['pPriceType'];
$pLocation = $_POST['pLocation'];
$bimage = $_POST['eImage'];

$email_id = $_POST['emailid'];

$query="SELECT * FROM user_profile WHERE email_id='$email_id'";
$result=mysql_query($query);
$row=mysql_fetch_array($result);

$user_id = $row['user_id'];

$event_id = rand(111111,999999);

$filename = "PETIMAGE".rand().".jpg";
file_put_contents("images/".$filename,base64_decode($bimage));

$query1="INSERT INTO user_pets VALUES('$user_id','$event_id','$email_id','$pCategory','$pName','$pAge','$pGender','$pBreed','$pABout','$pPrice','$pPriceType','$pLocation','$filename')";
$res1=mysql_query($query1);


if($res1)
{
	echo "Success";
}
else
{
	echo "Error while Adding";
}

 ?>