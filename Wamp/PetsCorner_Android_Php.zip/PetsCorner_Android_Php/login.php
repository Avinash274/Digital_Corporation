<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$password = $_POST['password'];

$query="SELECT * FROM user_login where email_id='$email_id' and password='$password'";
$res=mysql_query($query);
$row=mysql_fetch_assoc($res);

	if ($row == 0) 
	{
		echo "Login Failed";
	}
	else if($row != 0)
	{
		echo "Success";
	}
	else
	{
		echo "Connection Error";
	}

 ?>