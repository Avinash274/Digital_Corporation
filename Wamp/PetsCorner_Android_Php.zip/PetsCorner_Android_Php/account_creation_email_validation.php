<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];

$query="SELECT * FROM user_login where email_id='$email_id'";
$res=mysql_query($query);
$result=mysql_fetch_array($res);

if ($result > 0) 
	{
		echo "This Email is already registerd, try another email";
	}
	else if($result == 0)
	{
		$query1="SELECT * FROM account_creation_otp where email_id='$email_id'";
		$res1=mysql_query($query1);
		$result1=mysql_fetch_array($res1);
		if($result1 > 0)
		{
			$otp = rand(111111,999999);
			$query2="UPDATE account_creation_otp SET otp='$otp' WHERE email_id='$email_id'";
			$res2=mysql_query($query2);
			echo "Email Verified";

			$mailto = $email_id;
		    $headers = "MIME-Version: 1.0\r\n";
		    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		    $mailSub = "PetsCorner Account Creation";
		    $message = '<html><body>';
		    $message .= '<h2>PetsCorner</h2></br>';
		    $message .= '<p style="font-size:15px;">Hi there,</p>';
		    $message .= '</br>';
		    $message .= '<p style="font-size:15px;">We are sending you this email because you requested a New Account Creation. Please Enter the below given verification code to verify and start a new journery with petscorner.</p></br>';
		    $message .= "<p>Verification Code : <b>".$otp."</b></p></br>";
		    $message .= '<p style="font-size:15px;">If you did not request a new account creation request, you can ignore this email.</p></br>';
		    $message .= '<p style="font-size:15px;">Good luck! Hope it works.</p></br>';
		    $message .= '<h4>Thank You,</h4></br>';
		    $message .= '<h2>The Team PetsCorner</h2></br>';
		    $message .= '</body></html>';

		            
		    mail($mailto, $mailSub, $message, $headers);
		}
		else
		{
			$otp = rand(111111,999999);
			$query3="INSERT INTO account_creation_otp VALUES('$email_id','$otp')";
			$res3=mysql_query($query3);
			echo "Email Verified";

			$mailto = $email_id;
		    $headers = "MIME-Version: 1.0\r\n";
		    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		    $mailSub = "PetsCorner Account Creation";
		    $message = '<html><body>';
		    $message .= '<h2>PetsCorner</h2></br>';
		    $message .= '<p style="font-size:15px;">Hi there,</p>';
		    $message .= '</br>';
		    $message .= '<p style="font-size:15px;">We are sending you this email because you requested a New Account Creation. Please Enter the below given verification code to verify and start a new journery with petscorner.</p></br>';
		    $message .= "<p>Verification Code : <b>".$otp."</b></p></br>";
		    $message .= '<p style="font-size:15px;">If you did not request a new account creation request, you can ignore this email.</p></br>';
		    $message .= '<p style="font-size:15px;">Good luck! Hope it works.</p></br>';
		    $message .= '<h4>Thank You,</h4></br>';
		    $message .= '<h2>The Team PetsCorner</h2></br>';
		    $message .= '</body></html>';

		            
		    mail($mailto, $mailSub, $message, $headers);
		}
	}
	else
	{
		echo "Connection Error";
	}

 ?>