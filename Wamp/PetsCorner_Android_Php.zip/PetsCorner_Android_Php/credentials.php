<?php 

define("EMAILID", 'petscornerofficialac@gmail.com');
define('PASSWORD','PetsCorner@99');
 ?>