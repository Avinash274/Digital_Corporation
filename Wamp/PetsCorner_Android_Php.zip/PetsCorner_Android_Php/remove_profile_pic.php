<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$default = "pet_splash_logo_two.png";


$query="UPDATE user_profile SET profile_pic='$default' WHERE email_id='$email_id'";
$res=mysql_query($query);

	if ($res) 
	{
		echo "Removed Successfully";
	}
	else
	{
		echo "Connection Error";
	}

 ?>