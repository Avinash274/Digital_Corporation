<?php

$cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];

$query=mysql_query("SELECT * FROM user_profile WHERE email_id='$email_id'");

$flag=array();

if($query)
{
    while($row=mysql_fetch_assoc($query))
    {
        $flag[]=$row;
    }
    echo json_encode(array("book_request"=>$flag));
}
?>