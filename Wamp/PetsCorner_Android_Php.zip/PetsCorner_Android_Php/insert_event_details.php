<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...


$eTitle = $_POST['eTitle'];
$eDate = $_POST['eDate'];
$eTime = $_POST['eTime'];
$eDesc = $_POST['eDesc'];
$eLocation = $_POST['eLocation'];
$eState = $_POST['eState'];
$eContact = $_POST['eContact'];
$eEventLink = $_POST['eEventLink'];
$bimage = $_POST['eImage'];

$email_id = $_POST['emailid'];

$query="SELECT * FROM user_profile WHERE email_id='$email_id'";
$result=mysql_query($query);
$row=mysql_fetch_array($result);

$user_id = $row['user_id'];

$event_id = rand(111111,999999);

$filename = "EVENTIMAGE".rand().".jpg";
file_put_contents("images/".$filename,base64_decode($bimage));

$query1="INSERT INTO user_events VALUES('$user_id','$event_id','$email_id','$eTitle','$eDate','$eTime','$eDesc','$eLocation','$eState','$eContact','$eEventLink','$filename')";
$res1=mysql_query($query1);


if($res1)
{
	echo "Success";
}
else
{
	echo "Error while Adding";
}

 ?>