<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$idforDelete = $_POST['petRequestId'];


$query="DELETE FROM user_pet_request WHERE email_id='$email_id' AND request_id='$idforDelete'";
$result=mysql_query($query);


if($result)
{
	echo "Request Removed Successfully";
}
else
{
	echo "Error while Removing";
}
 ?>