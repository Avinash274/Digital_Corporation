<?php

$cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$sPetCategory = $_POST['sPetCategory'];
$sGender = $_POST['sGender'];
$sPriceType = $_POST['sPriceType'];
$sCity = $_POST['sCity'];

$query=mysql_query("SELECT * FROM user_pets WHERE petCategory='$sPetCategory' AND pGender='$sGender' AND pPriceType='$sPriceType' AND pLocation='$sCity'");

$flag=array();

if($query)
{
    while($row=mysql_fetch_assoc($query))
    {
        $flag[]=$row;
    }
    echo json_encode(array("user_books"=>$flag));
}
?>