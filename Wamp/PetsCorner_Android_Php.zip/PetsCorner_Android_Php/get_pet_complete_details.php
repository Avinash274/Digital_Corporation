<?php

$cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['ownerEmailId'];
$petId = $_POST['ownerPetId'];

$query=mysql_query("SELECT * FROM user_pets INNER JOIN user_profile ON user_pets.email_id=user_profile.email_id WHERE user_pets.email_id='$email_id' AND user_pets.pet_id='$petId'");


$flag=array();

if($query)
{
    while($row=mysql_fetch_assoc($query))
    {
        $flag[]=$row;
    }
    echo json_encode(array("user_books"=>$flag));
}
?>