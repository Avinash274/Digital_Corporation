<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$idforDelete = $_POST['eventId'];


$query="DELETE FROM  user_events WHERE user_email_id='$email_id' AND event_id='$idforDelete'";
$result=mysql_query($query);


if($result)
{
	echo "Event Removed Successfully";
}
else
{
	echo "Error while Removing";
}
 ?>