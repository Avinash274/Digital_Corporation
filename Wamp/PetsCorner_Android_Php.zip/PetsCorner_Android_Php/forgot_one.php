<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...
		
$email_id = $_POST['emailid'];

//first check whether provided email is registered or not
$query="SELECT * FROM user_login where email_id='$email_id'";
$res=mysql_query($query);
$result=mysql_fetch_array($res);

if ($result > 0) 
	{
		
		$otp_gen = rand(111111,999999);
		$query1 = "UPDATE user_login SET otp='$otp_gen' WHERE email_id='$email_id'";
		$res1=mysql_query($query1);
		
		echo "Email Verified";

			$mailto =  $email_id;
		    $headers = "MIME-Version: 1.0\r\n";
		    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		    $mailSub = "Account Password Details";
		    $message = '<html><body>';
		    $message .= '<h2>Pets Corner</h2></br>';
		    // $message .= '<p style="font-size:15px;">Hi '.$name.',</p>';
			$message .= '<p>Hi there !</p>';
		    $message .= '</br>';
		    $message .= '<p style="font-size:15px;text-align:justify;">We are sending you this email because you requested a password reset. Please Enter the below given verification code to verify and create a new password.</p></br>';
		    $message .= "<p>Verification Code : <b>".$otp_gen."</b></p></br>";
		    $message .= '<p style="font-size:15px;text-align:justify;">If you did not request a password reset, you can ignore this email.Your Password will not be changed.</p></br>';
		    $message .= '<p style="font-size:15px;">Good luck! Hope it works.</p></br>';
		    $message .= '<h4>Thank You,</h4></br>';
		    $message .= '<h2>The Team Pets Corner</h2></br>';
		    $message .= '</body></html>';


	   		 mail($mailto, $mailSub, $message, $headers);
	}
	else
	{
		echo "Email-Id Not Found !";
	}

 ?>