<?php

$cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$oPetCategory = $_POST['oPetCategory'];
$oGender = $_POST['oGender'];
$oPriceType = $_POST['oPriceType'];
$oCity = $_POST['oCity'];

$query=mysql_query("SELECT * FROM user_pets INNER JOIN user_profile ON user_pets.email_id=user_profile.email_id WHERE petCategory='$oPetCategory' AND pGender='$oGender' AND pPriceType='$oPriceType' AND pLocation='$oCity' ORDER BY RAND() LIMIT 0,100000000000000000");

$flag=array();

if($query)
{
    while($row=mysql_fetch_assoc($query))
    {
        $flag[]=$row;
    }
    echo json_encode(array("user_books"=>$flag));
}
?>