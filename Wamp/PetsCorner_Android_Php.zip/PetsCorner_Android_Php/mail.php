<?php 

			$mailto = "shashankdivate19@gmail.com";
		    $headers = "MIME-Version: 1.0\r\n";
		    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		    $mailSub = "BookSwap Account Creation";
		    $message = '<html><body>';
		    $message .= '<h2>Book Swap</h2></br>';
		    $message .= '<p style="font-size:15px;">Hi there,</p>';
		    $message .= '</br>';
		    $message .= '<p style="font-size:15px;">We are sending you this email because you requested a New Account Creation. Please Enter the below given verification code to verify and start a new journery with book swap.</p></br>';
		    $message .= '<p style="font-size:15px;">If you did not request a new account creation request, you can ignore this email.</p></br>';
		    $message .= '<p style="font-size:15px;">Good luck! Hope it works.</p></br>';
		    $message .= '<h4>Thank You,</h4></br>';
		    $message .= '<h2>The Team Book Swap</h2></br>';
		    $message .= '</body></html>';

		            
		    $result = mail($mailto, $mailSub, $message, $headers);

		    if($result)
		    {
		    	echo "success";
		    }
		    else
		    {
		    	echo "failed";
		    }

 ?>