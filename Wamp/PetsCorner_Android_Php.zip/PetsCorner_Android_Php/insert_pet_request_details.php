<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...


$pDescription = $_POST['pDescription'];
$pPlace = $_POST['pPlace'];

$email_id = $_POST['emailid'];

$query="SELECT * FROM user_profile WHERE email_id='$email_id'";
$result=mysql_query($query);
$row=mysql_fetch_array($result);

$user_id = $row['user_id'];

$event_id = rand(111111,999999);


$query1="INSERT INTO user_pet_request VALUES('$user_id','$event_id','$email_id','$pDescription','$pPlace')";
$res1=mysql_query($query1);


if($res1)
{
	echo "Success";
}
else
{
	echo "Error while Adding";
}

 ?>