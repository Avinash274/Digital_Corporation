<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...


$email_id = $_POST['email_id'];
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$gender = $_POST['gender'];
$contactNumber = $_POST['contactNumber'];
$password = $_POST['password'];
$profile_pic = "pet_splash_logo_two.png";

$user_id = rand(111111,999999);

$null = "null";

$query1="INSERT INTO user_profile VALUES('$user_id','$email_id','$firstName','$lastName','$gender','$contactNumber','$password','$profile_pic')";
$res1=mysql_query($query1);

$query2="INSERT INTO user_login VALUES('$email_id','$password','$null')";
$res2=mysql_query($query2);

if($res1 && $res2)
{
	echo "Account Created Successfully";
}
else
{
	echo "Error while Registering";
}

 ?>