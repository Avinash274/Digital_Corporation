<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$newPassword = $_POST['newPassword'];
$confirmPassword = $_POST['confirmPassword'];


if($newPassword == $confirmPassword)
{
	$query="UPDATE user_login SET password='$newPassword', otp='null' WHERE email_id='$email_id'";
	$res=mysql_query($query);

	$query1="UPDATE user_profile SET password='$newPassword' WHERE email_id='$email_id'";
	$res1=mysql_query($query1);

	if($res && $res1)
	{
		echo "Password Updated";
	}
	else
	{
		echo "Connection Error";
	}
}
else
{
	echo "Connection Error";
}
 ?>