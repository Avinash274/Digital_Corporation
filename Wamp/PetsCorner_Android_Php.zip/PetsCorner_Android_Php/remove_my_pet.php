<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$idforDelete = $_POST['petId'];


$query="DELETE FROM user_pets WHERE email_id='$email_id' AND pet_id='$idforDelete'";
$result=mysql_query($query);


if($result)
{
	echo "Pet Removed Successfully";
}
else
{
	echo "Error while Removing";
}
 ?>