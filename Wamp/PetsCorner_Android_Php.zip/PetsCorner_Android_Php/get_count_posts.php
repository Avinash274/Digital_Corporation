<?php

$cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['email_id'];

$query="SELECT COUNT(*) FROM user_pets where email_id='$email_id'";
$res=mysql_query($query);
$ba = mysql_fetch_array($res);

$query1="SELECT COUNT(*) FROM user_pet_request where email_id='$email_id'";
$res1=mysql_query($query1);
$ba1 = mysql_fetch_array($res1);

$flag=array();
$flag["requests"]=$ba1[0];
$flag["books"]=$ba[0];

echo json_encode($flag);

?>