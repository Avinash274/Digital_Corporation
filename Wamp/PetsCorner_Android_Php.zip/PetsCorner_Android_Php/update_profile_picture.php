<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$bimage = $_POST['bimage'];

$filename = "PROFILEIMAGE".rand().".jpg";
file_put_contents("images/".$filename,base64_decode($bimage));


$query="UPDATE user_profile SET profile_pic='$filename' WHERE email_id='$email_id'";
$res=mysql_query($query);

	if ($res) 
	{
		echo "Uploaded Successfully";
	}
	else
	{
		echo "Connection Error";
	}

 ?>