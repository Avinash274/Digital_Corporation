<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$otp = $_POST['otp'];

//first check whether provided email is registered or not
$query="SELECT * FROM user_login WHERE email_id='$email_id' AND otp='$otp'";
$res=mysql_query($query);
$result=mysql_fetch_array($res);

if ($result > 0) 
	{
		echo "OTP Verified";
	}
	else
	{
		echo "Invalid OTP";
	}

 ?>