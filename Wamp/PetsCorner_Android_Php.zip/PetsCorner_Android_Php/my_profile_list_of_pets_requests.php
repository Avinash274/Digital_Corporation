<?php

$cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

 $email_id = $_POST['myEmailId'];

        

$query=mysql_query("SELECT * FROM user_pet_request INNER JOIN user_profile ON user_pet_request.email_id=user_profile.email_id WHERE  user_pet_request.email_id='$email_id' ORDER BY RAND() LIMIT 0,100000000000000000");


$flag=array();

if($query)
{
    while($row=mysql_fetch_assoc($query))
    {
        $flag[]=$row;
    }
    echo json_encode(array("user_books"=>$flag));
}
?>