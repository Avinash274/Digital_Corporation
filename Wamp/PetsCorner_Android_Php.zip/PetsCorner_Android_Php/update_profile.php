<?php 

 $cn=mysql_connect("localhost","root",""); // host, username, password...
    	mysql_select_db("petscorner"); // db name...

$email_id = $_POST['emailid'];
$name = $_POST['name'];
$lastName = $_POST['lastName'];
$contact = $_POST['contact'];


$query="UPDATE user_profile SET firstName='$name',lastName='$lastName', contactNumber='$contact' WHERE email_id='$email_id'";
$res=mysql_query($query);

	if ($res) 
	{
		echo "Updated";
	}
	else
	{
		echo "Connection Error";
	}

 ?>